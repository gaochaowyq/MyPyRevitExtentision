# -*- encoding: utf-8 -*-
__doc__="设置构件价格"
import os
import sys
import rpw
from rpw import revit, DB, UI,db,doc
from System.Collections.Generic import List
import json
import subprocess as sp
#from Adaptor import BAT_ElementMaterial
#from Viewer.MyChart import MyCharts
import Helper
from Viewer.MyChart import MyCharts
from Adaptor.CovertToChartFormat import CoverToChartFormat as CTC
import pickle
import csv,codecs, cStringIO
import traceback
#Get Inside Wall And Outside Wall then show in on the Pin Table
CurrentView=doc.ActiveView


_filename=os.path.basename(doc.PathName)

def CovertToM3(input):
	return input/35.3147248
def CovertToM2(input):
	return input/10.7639104
def CovertToM(input):
	return input/3.2808399
def CovertToMM(input):
	return round(float(input/0.0032808),0)
#所有的价格按照m3计算
###################################################
#10 11
OUTPUT={"GetWalls":"14-10.20.03","Get_ST_Framings":"14-20.30.06","Get_CO_Framings":"14-20.20.06","Get_CO_Floors":"14-10.20.18","GetRoofs":"14-10.20.15","Get_ST_Columns":"14-20.30.03","GetCeiling":"14-10.20.24","Get_MEP_Pipe":"14-30.20.03","Get_MEP_Ducts":"14-30.40.03","Get_MEP_Wire_Pipe":"14-50.40"}

# 获取所有表14的Element

class MixPipe(object):
	def Name(self):
		UnwrapedElement=[i.unwrap() for i in self.Elements()]

		return ["{} {}mm".format(i.Name.encode('GB2312'),CovertToMM(i.Diameter)) for i in UnwrapedElement]


class MixConduit(object):
	def Name(self):
		UnwrapedElement=[i.unwrap() for i in self.Elements()]
		return ["{}{}".format(i.Name.encode('GB2312'),i.get_Parameter(DB.BuiltInParameter.RBS_CALCULATED_SIZE).AsString()) for i in UnwrapedElement]

                        
class GetAllBase(object):
	def __init__(self):
		self.param_id = DB.ElementId(DB.BuiltInParameter.UNIFORMAT_CODE)
	def Elements(self):
		parameter_filter = rpw.db.ParameterFilter(self.param_id,begins=self.AssembleCode)
		collector = rpw.db.Collector(parameter_filter=parameter_filter, is_type=False).get_elements(wrapped=True)
		return collector

	#GetAllElementsCosts As Lit
	def GetCosts(self):
		return [i.type.parameters['Cost'].value for i in self.Elements()]
	def GetAC(self):
		return [i.type.parameters['Assembly Code'].value for i in self.Elements()]
	def GetACName(self):
		return [i.type.parameters['Assembly Description'].value.encode('GB2312') for i in self.Elements()]
	def GetClassName(self):
		return [self.ClassName.encode('GB2312') for i in self.Elements()]
	def Name(self):
		UnwrapedElement=[i.unwrap() for i in self.Elements()]
		return [i.Name.encode('GB2312') for i in UnwrapedElement]
	def GetQutity(self):
		if self.unit=='m2':
			return [CovertToM2(i.parameters['Area'].value) for i in self.Elements()]
		elif self.unit=='m3':
			return [CovertToM3(i.parameters['Volume'].value) for i in self.Elements()]
		elif self.unit=='m':
			return [CovertToM(i.parameters['Length'].value) for i in self.Elements()]
	def OutPut(self):
		output=[]
		
		for i,c,b,d,f in zip(self.GetAC(),self.GetClassName(),self.GetCosts(),self.Name(),self.GetQutity()):
			_dict={}
			_dict['Assembly Code']=i
			_dict['Assembly Description'] =c
			_dict['Cost'] = b
			_dict['Unit'] = self.unit
			_dict['ElementName'] = d
			_dict['Qutity'] = f
			output.append(_dict)
		return output

	def OutPut_Total(self):
		
		all=self.OutPut()
		tem=[]
		try:
			for i in all:
				if i['ElementName'] in tem:
					pass
				else:
					tem.append(i['ElementName'])
			newout = []
			for i in tem:
				new={'Cost':0,'Count':0,'Qutity':0}
				for c in all:
					if c['ElementName']==i:
						new['ElementName']=c['ElementName']
						new['Assembly Code']=c['Assembly Code']
						new['Assembly Description'] = c['Assembly Description']
						new['Unit'] = c['Unit']
						new['Qutity'] =new['Qutity']+c['Qutity']
						new['Cost'] = new['Cost'] + c['Cost']
						new['Count'] = new['Count'] +1
				newout.append(new)



			return newout
		except:
			traceback.print_exc() 






class GetWalls(GetAllBase):
	def __init__(self):
		super(GetWalls,self).__init__()
		self.AssembleCode="14-10.20.03"
		self.ClassName="建筑墙"
		self.unit='m2'




class Get_Floors(GetAllBase):
	def __init__(self):
		super(Get_Floors,self).__init__()
		self.AssembleCode="14-10.20.18"
		self.ClassName="建筑楼地板"
		self.unit='m2'
class Get_CO_Floors(GetAllBase):
	def __init__(self):
		super(Get_CO_Floors,self).__init__()
		self.AssembleCode="14-20.20.03"
		self.ClassName="结构楼地板"
		self.unit='m2'

class GetCeiling(GetAllBase):
	def __init__(self):
		super(GetCeiling,self).__init__()
		self.AssembleCode="14-10.20.24"
		self.ClassName="建筑吊顶"
		self.unit='m2'

class GetRoofs(GetAllBase):
	def __init__(self):
		super(GetRoofs,self).__init__()
		self.AssembleCode="14-10.20.15"
		self.ClassName="建筑屋面"
		self.unit='m2'


class Get_ST_Framings(GetAllBase):
	def __init__(self):
		super(Get_ST_Framings,self).__init__()
		self.AssembleCode="14-20.30.06"
		self.ClassName="钢梁"
		self.unit='m3'
class Get_CO_Framings(GetAllBase):
	def __init__(self):
		super(Get_CO_Framings,self).__init__()
		self.AssembleCode="14-20.20.06"
		self.ClassName="钢筋混凝土梁"
		self.unit='m3'

class Get_CO_Columns(GetAllBase):
	def __init__(self):
		super(Get_CO_Columns,self).__init__()
		self.AssembleCode="14-20.20.09"
		self.ClassName="混凝土结构柱"
		self.unit='m3'
class Get_ST_Columns(GetAllBase):
	def __init__(self):
		super(Get_ST_Columns,self).__init__()
		self.AssembleCode="14-20.30.03"
		self.ClassName="钢结构柱"
		self.unit='m3'


class Get_S_Floors(GetAllBase):
	def __init__(self):
		super(Get_S_Floors,self).__init__()
		self.AssembleCode="14-20.20.03"
		self.ClassName="结构楼板"
		self.unit='m3'


class Get_MEP_Ducts(GetAllBase):
	def __init__(self):
		super(Get_MEP_Ducts,self).__init__()
		self.AssembleCode="14-30.40.03"
		self.ClassName="MEP_风管"
		self.unit='m'

class Get_MEP_Pipe(MixPipe,GetAllBase):
	def __init__(self):
		super(Get_MEP_Pipe,self).__init__()
		self.AssembleCode="14-30.20.03"
		self.ClassName="MEP_水管"
		self.unit='m'
		
class Get_MEP_Wire_Pipe(MixConduit,GetAllBase):
	def __init__(self):
		super(Get_MEP_Wire_Pipe,self).__init__()
		self.AssembleCode="14-50.40"
		self.ClassName="MEP_线缆"
		self.unit='m'
o=[]
for i in OUTPUT:
	c=eval(i)().OutPut_Total()
	try:
		output=CTC(c)
		output=output.OutPut()

		c=MyCharts(output)
		c.test1_chart()
		JsonFile=c.ToJson()
		o.append(JsonFile)
	except:
		pass
with open("d://{filename}.svf.lln".format(filename=_filename),'wb') as f:
	pickle.dump(o,f)
	print("{filename}.svf.lln is Writed".format(filename=_filename))

	





#input=[{'Name':'what','Value':10},{'Name':'what1','Value':9},{'Name':'what','Value':3},{'Name':'what1','Value':2}]

#output=[{'Name':'what','Value':13},{'Name':'what1','Value':11}]


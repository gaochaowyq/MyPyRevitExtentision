def CovertToM3(input):
	return input/35.3147248
def CovertToM2(input):
	return input/10.7639104